
package com.mphasis.prodbean;

public class Prodbean {
    int Prodid;
  String Prodname;
  int Prodprice;
  public int getProdid() {
	   	 return Prodid;
	    }
	    public void setProdid(int Prodid) {
	   	 this.Prodid= Prodid;
	    }
	    public String getProdname() {
	   	 return Prodname;
	    }
	    public void setProdname(String Prodname) {
	   	 this.Prodname = Prodname;
	    }
	    public int getProdprice() {
		   	 return Prodprice;
		    }
		    public void setProdprice(int Prodprice) {
		   	 this.Prodprice = Prodprice;
		    

	}
}