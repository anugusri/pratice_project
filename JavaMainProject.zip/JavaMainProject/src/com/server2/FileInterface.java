package com.server2;

public interface FileInterface {
	public void showAllFiles();
	public void addFile();
	public void deleteFile();
	abstract void searchFile();
}