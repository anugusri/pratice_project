

package Pack2;

import Pack1.*;

public class accessSpecifiers3 extends proaccessspecifiers {

	public static void main(String[] args) {
		accessSpecifiers3 obj1 = new accessSpecifiers3 ();   
	 
	
	  obj1.display();
}
}

