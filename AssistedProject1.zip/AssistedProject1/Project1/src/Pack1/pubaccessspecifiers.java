package Pack1;


//4. using public access specifiers

public class pubaccessspecifiers {

	public void display() 
  { 
      System.out.println("This is Public Access Specifiers"); 
  } 
}
